// export interface Quote {
//   user?: { id: number };
//   id: number;
//     insuranceType: 'fire' | 'burglary' | 'both';
//     customerName: string;
//     customerEmail: string;
//     lastName: string;
//     dob?: Date;
//     email: string;
//     phone: string;
//     address: string;
//     propertyType: 'House' | 'Apartment' | 'Condo' | 'Townhouse' | 'Villa' | 'Others';
//     propertyAddress: string;
//     propertyCity: string;
//     propertyState: string; // Added missing property
//   propertyZip: string; 
//     constructionType: 'Brick' | 'Wood' | 'Concrete' | 'Steel' | 'Mixed Material';
//     yearBuilt: number;
//     squareFootage: number;
//     numRooms: number;
//     numBathrooms: number;
//     numFloors: number;
//     isOccupiedFullTime: boolean;
//     securityFeatures: string[];
//     fireSafetyMeasures: string[];
//     sumInsured: number;
//     deductible: number;
//     additionalCoverages: string[];
//     policyDuration: '1' | '3' | '5' | 'custom';
//     policyStartDate: Date;
//     policyEndDate: Date;
//     renewalType: 'annually' | 'every-3-years' | 'every-5-years';
//     autoRenewal: boolean;
//     hasNearbyFireStation?: boolean;
//     otherFireSafetyMeasures?: string;
//     otherSecurityFeatures?: string;
//     hasHighValueItems?: boolean;
//     highValueItemsList?: string;
//     premium: number;
//     status: QuoteStatus;
//     createdAt: Date;
//     updatedAt: Date;
    
//   }

//   export type QuoteStatus = 'Draft' | 'Submitted' | 'Approved' | 'Bound' | 'Rejected'; // Exported QuoteStatus

 



// // quote.model.ts
// export interface Quote {
//   country: any;
//   user?: { id: number | null }; // Allow null ID
//   id: number;
//   insuranceType: 'fire' | 'burglary' | 'both';
//   customerName: string;
//   customerEmail?: string; // Make optional as you use email instead
//   lastName?: string; // Make optional as you use fullName instead
//   dob?: Date;
//   email: string;
//   phone: string;
//   address: string;
//   propertyType: 'House' | 'Apartment' | 'Condo' | 'Townhouse' | 'Villa' | 'Others' | string; // Allow any string
//   propertyAddress: string;
//   propertyCity: string;
//   propertyState: string;
//   propertyZip: string;
//   constructionType: 'Brick' | 'Wood' | 'Concrete' | 'Steel' | 'Mixed Material' | string; // Allow any string
//   yearBuilt: number;
//   squareFootage: number;
//   numRooms: number;
//   numDoors: number; // Add this missing property
//   numWindows: number; // Add this missing property
//   numBathrooms?: number; // Make optional since your form doesn't have it
//   numFloors: number;
//   isOccupiedFullTime: boolean;
//   isGatedCommunity?: boolean; // Add this property
//   securityFeatures: string[];
//   fireSafetyMeasures: string[];
//   sumInsured?: number; // Optional as you're using sumInsuredHouse and sumInsuredContents
//   sumInsuredHouse?: number; // Add this property
//   sumInsuredContents?: number; // Add this property
//   deductible: number;
//   additionalCoverages?: string[]; // Make optional
//   policyDuration: '1' | '3' | '5' | 'custom' | string; // Allow any string
//   policyStartDate?: Date; // Make optional
//   policyEndDate?: Date; // Make optional
//   renewalType?: 'annually' | 'every-3-years' | 'every-5-years'; // Make optional
//   autoRenewal?: boolean; // Make optional
//   hasNearbyFireStation?: boolean;
//   otherFireSafetyMeasures?: string;
//   otherSecurityFeatures?: string;
//   hasHighValueItems?: boolean;
//   highValueItemsList?: string;
//   premium?: number; // Make optional since it's not in your form
//   status: QuoteStatus;
//   createdAt: Date;
//   updatedAt: Date;
// }

// export type QuoteStatus = 'Draft' | 'Submitted' | 'Approved' | 'Bound' | 'Rejected';


export interface Quote {
  
  country?: 'USA' | 'India';
  user?: { id: number | null };
  id: number;
  insuranceType: 'fire' | 'burglary' | 'both';
  customerName: string;
  customerEmail?: string;
  lastName?: string;
  dob?: Date;
  email: string;
  phone: string;
  address: string;
  propertyType: 'House' | 'Apartment' | 'Condo' | 'Townhouse' | 'Villa' | 'Others' | string;
  propertyAddress: string;
  propertyCity: string;
  propertyState: string;
  propertyZip: string;
  constructionType: 'Brick' | 'Wood' | 'Concrete' | 'Steel' | 'Mixed Material' | string;
  
  // Added the missing properties that were causing errors
  builtYear?: number;       // Added (same as yearBuilt but for template)
  yearBuilt: number;        // Kept original
  propertyValue?: number;   // Added
  coverageDetails?: any;    // Added
  notes?: string;           // Added
  
  squareFootage: number;
  numRooms: number;
  numDoors: number;
  numWindows: number;
  numBathrooms?: number;
  numFloors: number;
  isOccupiedFullTime: boolean;
  isGatedCommunity?: boolean;
  securityFeatures: string[];
  fireSafetyMeasures: string[];
  sumInsured?: number;
  sumInsuredHouse?: number;
  sumInsuredContents?: number;
  deductible: number;
  additionalCoverages?: string[];
  policyDuration: '1' | '3' | '5' | 'custom' | string;
  policyStartDate?: Date;
  policyEndDate?: Date;
  renewalType?: 'annually' | 'every-3-years' | 'every-5-years';
  autoRenewal?: boolean;
  hasNearbyFireStation?: boolean;
  otherFireSafetyMeasures?: string;
  otherSecurityFeatures?: string;
  hasHighValueItems?: boolean;
  highValueItemsList?: string;
  premium: number;
  status: QuoteStatus;
  createdAt: Date;
  updatedAt: Date;
}

export type QuoteStatus = 'Draft' | 'Submitted' | 'Approved' | 'Bound' | 'Rejected';