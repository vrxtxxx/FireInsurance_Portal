

// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Router } from '@angular/router';
// import { Observable, throwError } from 'rxjs';
// import { catchError } from 'rxjs/operators';
// import { Quote } from '../models/quote.model';
// import { AuthService } from './auth.service';

// @Injectable({
//   providedIn: 'root'
// })
// export class QuoteService {
//   private apiUrl = 'http://localhost:8080/api';

//   constructor(
//     private http: HttpClient,
//     private router: Router,
//     private authService: AuthService
//   ) {}

//   private getHeaders(): HttpHeaders {
//     const token = this.authService.getToken();
//     if (!token) {
//       this.authService.logout();
//       throw new Error('No authentication token available');
//     }
    
//     return new HttpHeaders({
//       'Authorization': `Bearer ${token}`,
//       'Content-Type': 'application/json'
//     });
//   }

//   createQuote(quoteData: Partial<Quote>): Observable<Quote> {
//     return this.http.post<Quote>(`${this.apiUrl}/quotes`, quoteData, { 
//       headers: this.getHeaders()
//     }).pipe(
//       catchError(this.handleError)
//     );
//   }

//   getUserQuotes(userId: number): Observable<Quote[]> {
//     return this.http.get<Quote[]>(`${this.apiUrl}/quotes/user/${userId}`, {
//       headers: this.getHeaders()
//     }).pipe(
//       catchError(this.handleError)
//     );
//   }

//   getQuoteById(id: number): Observable<Quote> {
//     return this.http.get<Quote>(`${this.apiUrl}/${id}`);
//   }
  
//   updateQuote(id: number, quote: Quote): Observable<Quote> {
//     return this.http.put<Quote>(`${this.apiUrl}/${id}`, quote);
//   }
  
//   deleteQuote(id: number): Observable<void> {
//     return this.http.delete<void>(`${this.apiUrl}/quotes/${id}`, {
//       headers: this.getHeaders()
//     }).pipe(
//       catchError(this.handleError)
//     );
//   }

//   private handleError(error: any): Observable<never> {
//     console.error('API Error:', error);
//     if (error.status === 401 || error.status === 403) {
//       // Handle unauthorized/forbidden errors
//     }
//     return throwError(() => error);
//   }
// }

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Quote } from '../models/quote.model';
import { AuthService } from './auth.service';
interface FireSafetyDiscounts {
  sprinklers: number;
  alarms: number;
  extinguishers: number;
  none: number;
}

interface BurglaryDiscounts {
  alarms: number;
  cameras: number;
  securityService: number;
  none: number;
}

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  private apiUrl = 'http://localhost:8080/api/quotes';
  private fireSafetyDiscounts: FireSafetyDiscounts = {
    sprinklers: 0.15,
    alarms: 0.10,
    extinguishers: 0.05,
    none: 0
  };

  private burglaryDiscounts: BurglaryDiscounts = {
    alarms: 0.10,
    cameras: 0.08,
    securityService: 0.12,
    none: 0
  };

  constructor(
    private http: HttpClient,
    private router: Router,
    private authService: AuthService
  ) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    if (!token) {
      this.authService.logout();
      throw new Error('No authentication token available');
    }

    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  createQuote(quoteData: Partial<Quote>): Observable<Quote> {
    return this.http.post<Quote>(`${this.apiUrl}`, quoteData, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }

  getUserQuotes(userId: number): Observable<Quote[]> {
    return this.http.get<Quote[]>(`${this.apiUrl}/user/${userId}`, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }

  getQuoteById(id: number): Observable<Quote> {
    return this.http.get<Quote>(`${this.apiUrl}/${id}`, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }

  updateQuote(id: number, quote: Quote): Observable<Quote> {
    return this.http.put<Quote>(`${this.apiUrl}/${id}`, quote, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }
  getDashboardStats(): Observable<any> {
    return this.http.get(`${this.apiUrl}/dashboard-stats`, {
      headers: this.getHeaders()
    });
  }
  deleteQuote(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }

  calculatePremiumOnServer(quoteData: Partial<Quote>): Observable<number> {
    return this.http.post<number>(`${this.apiUrl}/calculate-premium`, quoteData, {
        headers: this.getHeaders()
    }).pipe(
        catchError(this.handleError.bind(this))
    );
  }
  bindQuote(id: number): Observable<Quote> {
    return this.http.post<Quote>(`${this.apiUrl}/${id}/bind`, {}, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }
  
  private handleError(error: any): Observable<never> {
    console.error('API Error:', error);
    if (error.status === 401 || error.status === 403) {
      this.authService.logout();
      this.router.navigate(['/login']);
    }
    return throwError(() => error);
  }
}
