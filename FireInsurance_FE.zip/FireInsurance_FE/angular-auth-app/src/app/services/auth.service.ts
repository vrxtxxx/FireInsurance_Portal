// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { tap } from 'rxjs/operators';
// import { Router } from '@angular/router';
// import { JwtHelperService } from '@auth0/angular-jwt';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   private baseUrl = 'http://localhost:8080/api/auth';
//   private jwtHelper = new JwtHelperService();

//   constructor(private http: HttpClient, private router: Router) {}

//   // login(email: string, password: string): Observable<any> {
//   //   return this.http.post(`${this.baseUrl}/login`, { email, password });
//   // }
//   login(email: string, password: string): Observable<any> {
//     return this.http.post(`${this.baseUrl}/login`, { email, password }).pipe(
//       tap((response: any) => {
//         if (response.token && response.email && response.userId) {
//           this.storeAuthData(response.token, response.email, response.userId);
//         } else {
//           throw new Error('Invalid login response format');
//         }
//       })
//     );
//   }

//   register(userData: any): Observable<any> {
//     return this.http.post(`${this.baseUrl}/register`, userData);
//   }

//   storeToken(token: string): void {
//     localStorage.setItem('jwt_token', token);
//   }
  
//   getToken(): string {
//     return localStorage.getItem('token') || '';
//   }
    
//   isLoggedIn(): boolean {
//     const token = this.getToken();
//     return token != null && !this.jwtHelper.isTokenExpired(token);
//   }
  
//   getCurrentUserEmail(): string | null {
//     const token = this.getToken();
//     if (token) {
//       return this.jwtHelper.decodeToken(token).sub;
//     }
//     return null;
//   }

//   logout(): void {
//     localStorage.removeItem('jwt_token');
//     this.router.navigate(['/login']);
//   }

//   storeAuthData(token: string, email: string, userId: number): void {
//     localStorage.setItem('jwt_token', token);
//     localStorage.setItem('email', email);
//     localStorage.setItem('userId', userId.toString());
//   }
  
//   getCurrentUserId(): number | null {
//     const userId = localStorage.getItem('userId');
//     return userId ? parseInt(userId) : null;
//   }
// }


import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'http://localhost:8080/api/auth';
  private jwtHelper = new JwtHelperService();

  constructor(private http: HttpClient, private router: Router) {}

  login(email: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, { email, password }).pipe(
      tap((response: any) => {
        if (response.token && response.email && response.userId) {
          this.storeAuthData(response.token, response.email, response.userId);
        } else {
          throw new Error('Invalid login response format');
        }
      })
    );
  }
  getDashboardStats(): Observable<any> {
    return this.http.get(`${this.baseUrl}/dashboard-stats`);
  }
  register(userData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, userData);
  }

  storeAuthData(token: string, email: string, userId: number): void {
    localStorage.setItem('jwt_token', token);
    localStorage.setItem('email', email);
    localStorage.setItem('userId', userId.toString());
  }

  getToken(): string | null {
    return localStorage.getItem('jwt_token'); // Fixed to match the key used in storeAuthData
  }

  isLoggedIn(): boolean {
    const token = this.getToken();
    return !!token && !this.jwtHelper.isTokenExpired(token);
  }

  getCurrentUserEmail(): string | null {
    // Use the stored email directly instead of decoding token
    return localStorage.getItem('email');
  }

  getCurrentUserId(): number | null {
    const userId = localStorage.getItem('userId');
    return userId ? parseInt(userId) : null;
  }

  clearAuthData(): void {
    localStorage.removeItem('jwt_token');
    localStorage.removeItem('email');
    localStorage.removeItem('userId');
  }

  logout(): void {
    this.clearAuthData();
    this.router.navigate(['/login']);
  }

  // Optional: Token refresh functionality
  refreshToken(): Observable<any> {
    return this.http.post(`${this.baseUrl}/refresh-token`, {
      token: this.getToken()
    }).pipe(
      tap((response: any) => {
        if (response.token) {
          this.storeToken(response.token);
        }
      })
    );
  }

    storeToken(token: string): void {
    localStorage.setItem('jwt_token', token);
  }
}