// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
// import { QuoteService } from '../../services/quote.service';
// import { Quote } from '../../models/quote.model';
// import { ActivatedRoute, Router } from '@angular/router';
// import { AuthService } from '../../services/auth.service';

// @Component({
//   selector: 'app-new-quote',
//   standalone: true,
//   imports: [CommonModule, ReactiveFormsModule],
//   templateUrl: './new-quote.component.html',
//   styleUrls: ['./new-quote.component.css']
// })
// export class NewQuoteComponent implements OnInit {
//   quoteForm!: FormGroup;
//   isEditMode = false;
//   currentQuoteId: number | null = null;
//   progress = 0; // Progress percentage

//   // Define security measures for checkboxes
//   fireMeasures = [
//     { id: 'fireExtinguishers', label: 'Fire Extinguishers' },
//     { id: 'smokeDetectors', label: 'Smoke Detectors' },
//     { id: 'sprinklerSystem', label: 'Sprinkler System' },
//     { id: 'fireAlarmSystem', label: 'Fire Alarm System' },
//     { id: 'fireEscapeRoutes', label: 'Fire Escape Routes' }
//   ];

//   burglaryMeasures = [
//     { id: 'alarmSystem', label: 'Alarm System' },
//     { id: 'securityCameras', label: 'Security Cameras' },
//     { id: 'deadbolts', label: 'Deadbolts' },
//     { id: 'barsOnWindows', label: 'Bars on Windows' },
//     { id: 'cctvCameras', label: 'CCTV Cameras' },
//     { id: 'securityGuards', label: 'Security Guards' },
//     { id: 'burglarAlarmSystem', label: 'Burglar Alarm System' },
//     { id: 'motionSensorLights', label: 'Motion Sensor Lights' },
//     { id: 'strongLocks', label: 'Strong Locks & Reinforced Doors' }
//   ];
  
//   constructor(
//     private fb: FormBuilder,
//     private quotesService: QuoteService,
//     private router: Router,
//     private route: ActivatedRoute,
//     private authService: AuthService
//   ) {}

//   ngOnInit(): void {
//     this.initializeForm();
//     this.loadQuoteIfEditing();
//     this.updateProgress(); // Initialize progress
//   }

//   initializeForm(): void {
//     // Create form controls for fire measures
//     const fireMeasuresControls: Record<string, any> = {};
//     this.fireMeasures.forEach(measure => {
//       fireMeasuresControls[measure.id] = [false];
//     });

//     // Create form controls for burglary measures
//     const burglaryMeasuresControls:Record<string, any>  = {};
//     this.burglaryMeasures.forEach(measure => {
//       burglaryMeasuresControls[measure.id] = [false];
//     });

//     this.quoteForm = this.fb.group({
//       // Contact Details
//       fullName: ['', [Validators.required, Validators.minLength(2)]],
//       dob: ['', Validators.required],
//       phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
//       email: ['', [Validators.required, Validators.email]],
//       address1: ['', [Validators.required]],
//       address2: [''],
//       country: ['', Validators.required],
//       state: ['', Validators.required],
//       city: ['', Validators.required],
//       zip: ['', [Validators.required, Validators.pattern(/^[0-9]{5,10}$/)]],
      
//       // Property Details
//       propertyAge: [null, [Validators.required, Validators.min(0)]],
//       constructionType: ['', Validators.required],
//       propertyType: ['', Validators.required],
//       rooms: [null, [Validators.required, Validators.min(1)]],
//       doors: [null, [Validators.required, Validators.min(1)]],
//       windows: [null, [Validators.required, Validators.min(1)]],
//       area: [null, [Validators.required, Validators.min(100)]],
//       floors: [null, [Validators.required, Validators.min(1)]],
//       isGated: ['', Validators.required],
//       occupied: ['', Validators.required],
      
//       // Coverage Details
//       sumInsuredHouse: [null, [Validators.required, Validators.min(10000)]],
//       sumInsuredContents: [null, [Validators.required, Validators.min(5000)]],
//       deductibles: [null, [Validators.required, Validators.min(0)]],
//       policyDuration: ['', Validators.required],
      
//       // Security Measures - Fire Protection
//       ...fireMeasuresControls,
      
//       // Security Measures - Burglary Protection
//       ...burglaryMeasuresControls
//     });

//     // Add form field change listeners for progress tracking
//     this.setupFormListeners();
//   }

//   private setupFormListeners(): void {
//     // Watch for changes to update progress
//     this.quoteForm.valueChanges.subscribe(() => {
//       this.updateProgress();
//     });
//   }

//   updateProgress(): void {
//     const totalRequiredFields = 20; // Total number of required fields
//     let completedFields = 0;

//     // Check Contact Details
//     if (this.quoteForm.get('fullName')?.valid) completedFields++;
//     if (this.quoteForm.get('dob')?.valid) completedFields++;
//     if (this.quoteForm.get('phone')?.valid) completedFields++;
//     if (this.quoteForm.get('email')?.valid) completedFields++;
//     if (this.quoteForm.get('address1')?.valid) completedFields++;
//     if (this.quoteForm.get('country')?.valid) completedFields++;
//     if (this.quoteForm.get('state')?.valid) completedFields++;
//     if (this.quoteForm.get('city')?.valid) completedFields++;
//     if (this.quoteForm.get('zip')?.valid) completedFields++;

//     // Check Property Details
//     if (this.quoteForm.get('propertyAge')?.valid) completedFields++;
//     if (this.quoteForm.get('constructionType')?.valid) completedFields++;
//     if (this.quoteForm.get('propertyType')?.valid) completedFields++;
//     if (this.quoteForm.get('rooms')?.valid) completedFields++;
//     if (this.quoteForm.get('doors')?.valid) completedFields++;
//     if (this.quoteForm.get('windows')?.valid) completedFields++;
//     if (this.quoteForm.get('area')?.valid) completedFields++;
//     if (this.quoteForm.get('floors')?.valid) completedFields++;
//     if (this.quoteForm.get('isGated')?.valid) completedFields++;
//     if (this.quoteForm.get('occupied')?.valid) completedFields++;

//     // Check Coverage Details
//     if (this.quoteForm.get('sumInsuredHouse')?.valid) completedFields++;
//     if (this.quoteForm.get('sumInsuredContents')?.valid) completedFields++;
//     if (this.quoteForm.get('deductibles')?.valid) completedFields++;
//     if (this.quoteForm.get('policyDuration')?.valid) completedFields++;

//     // Check if at least one fire safety measure is selected
//     const hasFireMeasure = this.fireMeasures.some(measure => 
//       this.quoteForm.get(measure.id)?.value === true
//     );
//     if (hasFireMeasure) completedFields++;

//     // Check if at least one burglary feature is selected
//     const hasBurglaryMeasure = this.burglaryMeasures.some(measure => 
//       this.quoteForm.get(measure.id)?.value === true
//     );
//     if (hasBurglaryMeasure) completedFields++;

//     // Calculate progress percentage
//     this.progress = Math.round((completedFields / totalRequiredFields) * 100);
//   }

//   loadQuoteIfEditing(): void {
//     this.route.queryParams.subscribe(params => {
//       if (params['id']) {
//         this.quotesService.getQuoteById(+params['id']).subscribe(quote => {
//           if (quote) {
//             this.currentQuoteId = quote.id;
//             this.isEditMode = true;
//             this.patchFormValues(quote);
//           }
//         });
//       }
//     });
//   }

//   patchFormValues(quote: Quote): void {
//     // Basic fields
//     this.quoteForm.patchValue({
//       fullName: quote.customerName,
//       email: quote.email,
//       phone: quote.phone,
//       // Map other fields from quote to form fields
//       // You'll need to adjust this based on your Quote model structure
//     });

//     // Handle fire safety measures
//     this.fireMeasures.forEach(measure => {
//       if (quote.fireSafetyMeasures?.includes(measure.label)) {
//         this.quoteForm.get(measure.id)?.setValue(true);
//       }
//     });
    
//     // Handle burglary features
//     this.burglaryMeasures.forEach(measure => {
//       if (quote.securityFeatures?.includes(measure.label)) {
//         this.quoteForm.get(measure.id)?.setValue(true);
//       }
//     });
//   }

//   formatDate(date: Date | string): string {
//     if (!date) return '';
//     const d = new Date(date);
//     return d.toISOString().split('T')[0];
//   }

//   onSubmit(): void {
//     if (this.quoteForm.valid) {
//       // const userId = this.authService.getCurrentUserId();
//       // if (!userId) {
//       //   this.router.navigate(['/login']);
//       //   return;
//       // }
//        const token = localStorage.getItem('token'); // or however you get the token
//       if (!token) {
//         this.router.navigate(['/login']);
//         return;
//       }
  
//       const formValue = this.quoteForm.value;
      
//       // Prepare the security features and fire safety measures
//       const securityFeatures = this.burglaryMeasures
//         .filter(measure => formValue[measure.id])
//         .map(measure => measure.label);
        
//       const fireSafetyMeasures = this.fireMeasures
//         .filter(measure => formValue[measure.id])
//         .map(measure => measure.label);
      
//       // Prepare the quote data to match your backend model
//       // In your onSubmit() method: 
// const quoteData: Quote = {
//   id: this.isEditMode && this.currentQuoteId ? this.currentQuoteId : 0,
//   // user: { id: userId }, // Now this is safe since we checked for null above
//   user: { id: this.authService.getCurrentUserId() },
//   customerName: formValue.fullName,
//   email: formValue.email,
//   phone: formValue.phone,
//   address: `${formValue.address1} ${formValue.address2 || ''}`,
//   propertyType: formValue.propertyType,
//   propertyAddress: `${formValue.address1} ${formValue.address2 || ''}`,
//   propertyCity: formValue.city,
//   propertyState: formValue.state,
//   propertyZip: formValue.zip,
//   constructionType: formValue.constructionType,
//   yearBuilt: new Date().getFullYear() - formValue.propertyAge,
//   squareFootage: formValue.area,
//   numRooms: formValue.rooms,
//   numDoors: formValue.doors,
//   numWindows: formValue.windows,
//   numFloors: formValue.floors,
//   isOccupiedFullTime: formValue.occupied === 'yes',
//   isGatedCommunity: formValue.isGated === 'yes',
//   securityFeatures: securityFeatures,
//   fireSafetyMeasures: fireSafetyMeasures,
//   sumInsuredHouse: formValue.sumInsuredHouse,
//   sumInsuredContents: formValue.sumInsuredContents,
//   deductible: formValue.deductibles,
//   policyDuration: formValue.policyDuration,
//   status: 'Submitted',
//   insuranceType: 'both', // Default to both since this is a fire & burglary quote
//   createdAt: new Date(),
//   updatedAt: new Date()
// };
  
//       console.log('Submitting quote:', quoteData);
  
//       if (this.isEditMode && this.currentQuoteId) {
//         this.quotesService.updateQuote(this.currentQuoteId, quoteData).subscribe({
//           next: (response) => {
//             console.log('Quote updated successfully:', response);
//             this.showSuccessAlert('Quote updated successfully!');
//             this.router.navigate(['/my-quotes']);
//           },
//           error: (err) => {
//             console.error('Error updating quote:', err);
//             this.showErrorAlert('Failed to update quote. Please try again.');
//           }
//         });
//       } else {
//         this.quotesService.createQuote(quoteData).subscribe({
//           next: (response) => {
//             console.log('Quote created successfully:', response);
//             this.showSuccessAlert('Quote submitted successfully!');
//             this.router.navigate(['/my-quotes']);
//           },
//           error: (err) => {
//             console.error('Error creating quote:', err);
//             this.showErrorAlert('Failed to submit quote. Please try again.');
//           }
//         });
//       }
//     } else {
//       this.markFormGroupTouched(this.quoteForm);
//     }
//   }
  
//   private showSuccessAlert(message: string): void {
//     // You can replace this with a proper toast/notification system
//     alert(message);
//   }
  
//   private showErrorAlert(message: string): void {
//     alert(message);
//   }

//   getFormErrors(): any {
//     const errors: any = {};
//     Object.keys(this.quoteForm.controls).forEach(key => {
//       const control = this.quoteForm.get(key);
//       if (control?.errors) {
//         errors[key] = control.errors;
//       }
//     });
//     return errors;
//   }

//   markFormGroupTouched(formGroup: FormGroup) {
//     Object.values(formGroup.controls).forEach(control => {
//       control.markAsTouched();
//       if (control instanceof FormGroup) {
//         this.markFormGroupTouched(control);
//       }
//     });
//   }

//   saveAsDraft(): void {
//     const formValue = this.quoteForm.value;
    
//     // Similar to onSubmit but with Draft status
//     const securityFeatures = this.burglaryMeasures
//       .filter(measure => formValue[measure.id])
//       .map(measure => measure.label);
      
//     const fireSafetyMeasures = this.fireMeasures
//       .filter(measure => formValue[measure.id])
//       .map(measure => measure.label);
    
//     const quoteData: Partial<Quote> = {
//       id: this.isEditMode && this.currentQuoteId ? this.currentQuoteId : 0,
//       user: { id: this.authService.getCurrentUserId() },
//       customerName: formValue.fullName,
//       email: formValue.email,
//       phone: formValue.phone,
//       // Include all other fields as needed
//       securityFeatures: securityFeatures,
//       fireSafetyMeasures: fireSafetyMeasures,
//       status: 'Draft',
//       createdAt: new Date(),
//       updatedAt: new Date()
//     };

//     if (this.isEditMode && this.currentQuoteId) {
//       this.quotesService.updateQuote(this.currentQuoteId, quoteData as Quote).subscribe({
//         next: () => {
//           this.showSuccessAlert('Quote saved as draft!');
//           this.router.navigate(['/my-quotes']);
//         },
//         error: (err) => {
//           console.error('Error saving draft:', err);
//           this.showErrorAlert('Failed to save draft. Please try again.');
//         }
//       });
//     } else {
//       this.quotesService.createQuote(quoteData as Quote).subscribe({
//         next: () => {
//           this.showSuccessAlert('Quote saved as draft!');
//           this.router.navigate(['/my-quotes']);
//         },
//         error: (err) => {
//           console.error('Error saving draft:', err);
//           this.showErrorAlert('Failed to save draft. Please try again.');
//         }
//       });
//     }
//   }
// }


// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
// import { QuoteService } from '../../services/quote.service';
// import { Quote } from '../../models/quote.model';
// import { ActivatedRoute, Router } from '@angular/router';
// import { AuthService } from '../../services/auth.service';

// @Component({
//   selector: 'app-new-quote',
//   standalone: true,
//   imports: [CommonModule, ReactiveFormsModule],
//   templateUrl: './new-quote.component.html',
//   styleUrls: ['./new-quote.component.css']
// })
// export class NewQuoteComponent implements OnInit {
//   quoteForm!: FormGroup;
//   isEditMode = false;
//   currentQuoteId: number | null = null;
//   progress = 0; // Progress percentage

//   // Define security measures for checkboxes
//   fireMeasures = [
//     { id: 'fireExtinguishers', label: 'Fire Extinguishers' },
//     { id: 'smokeDetectors', label: 'Smoke Detectors' },
//     { id: 'sprinklerSystem', label: 'Sprinkler System' },
//     { id: 'fireAlarmSystem', label: 'Fire Alarm System' },
//     { id: 'fireEscapeRoutes', label: 'Fire Escape Routes' }
//   ];

//   burglaryMeasures = [
//     { id: 'alarmSystem', label: 'Alarm System' },
//     { id: 'securityCameras', label: 'Security Cameras' },
//     { id: 'deadbolts', label: 'Deadbolts' },
//     { id: 'barsOnWindows', label: 'Bars on Windows' },
//     { id: 'cctvCameras', label: 'CCTV Cameras' },
//     { id: 'securityGuards', label: 'Security Guards' },
//     { id: 'burglarAlarmSystem', label: 'Burglar Alarm System' },
//     { id: 'motionSensorLights', label: 'Motion Sensor Lights' },
//     { id: 'strongLocks', label: 'Strong Locks & Reinforced Doors' }
//   ];
  
//   constructor(
//     private fb: FormBuilder,
//     private quotesService: QuoteService,
//     private router: Router,
//     private route: ActivatedRoute,
//     private authService: AuthService
//   ) {}

//   ngOnInit(): void {
//     this.initializeForm();
//     this.loadQuoteIfEditing();
//     this.updateProgress(); // Initialize progress
//   }

//   initializeForm(): void {
//     // Create form controls for fire measures
//     const fireMeasuresControls: Record<string, any> = {};
//     this.fireMeasures.forEach(measure => {
//       fireMeasuresControls[measure.id] = [false];
//     });

//     // Create form controls for burglary measures
//     const burglaryMeasuresControls:Record<string, any>  = {};
//     this.burglaryMeasures.forEach(measure => {
//       burglaryMeasuresControls[measure.id] = [false];
//     });

//     this.quoteForm = this.fb.group({
//       // Contact Details
//       fullName: ['', [Validators.required, Validators.minLength(2)]],
//       dob: ['', Validators.required],
//       phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
//       email: ['', [Validators.required, Validators.email]],
//       address1: ['', [Validators.required]],
//       address2: [''],
//       country: ['', Validators.required],
//       state: ['', Validators.required],
//       city: ['', Validators.required],
//       zip: ['', [Validators.required, Validators.pattern(/^[0-9]{5,10}$/)]],
      
//       // Property Details
//       propertyAge: [null, [Validators.required, Validators.min(0)]],
//       constructionType: ['', Validators.required],
//       propertyType: ['', Validators.required],
//       rooms: [null, [Validators.required, Validators.min(1)]],
//       doors: [null, [Validators.required, Validators.min(1)]],
//       windows: [null, [Validators.required, Validators.min(1)]],
//       area: [null, [Validators.required, Validators.min(100)]],
//       floors: [null, [Validators.required, Validators.min(1)]],
//       isGated: ['', Validators.required],
//       occupied: ['', Validators.required],
      
//       // Coverage Details
//       sumInsuredHouse: [null, [Validators.required, Validators.min(10000)]],
//       sumInsuredContents: [null, [Validators.required, Validators.min(5000)]],
//       deductibles: [null, [Validators.required, Validators.min(0)]],
//       policyDuration: ['', Validators.required],
      
//       // Security Measures - Fire Protection
//       ...fireMeasuresControls,
      
//       // Security Measures - Burglary Protection
//       ...burglaryMeasuresControls
//     });

//     // Add form field change listeners for progress tracking
//     this.setupFormListeners();
//   }

//   private setupFormListeners(): void {
//     // Watch for changes to update progress
//     this.quoteForm.valueChanges.subscribe(() => {
//       this.updateProgress();
//     });
//   }

//   updateProgress(): void {
//     const totalRequiredFields = 20; // Total number of required fields
//     let completedFields = 0;

//     // Check Contact Details
//     if (this.quoteForm.get('fullName')?.valid) completedFields++;
//     if (this.quoteForm.get('dob')?.valid) completedFields++;
//     if (this.quoteForm.get('phone')?.valid) completedFields++;
//     if (this.quoteForm.get('email')?.valid) completedFields++;
//     if (this.quoteForm.get('address1')?.valid) completedFields++;
//     if (this.quoteForm.get('country')?.valid) completedFields++;
//     if (this.quoteForm.get('state')?.valid) completedFields++;
//     if (this.quoteForm.get('city')?.valid) completedFields++;
//     if (this.quoteForm.get('zip')?.valid) completedFields++;

//     // Check Property Details
//     if (this.quoteForm.get('propertyAge')?.valid) completedFields++;
//     if (this.quoteForm.get('constructionType')?.valid) completedFields++;
//     if (this.quoteForm.get('propertyType')?.valid) completedFields++;
//     if (this.quoteForm.get('rooms')?.valid) completedFields++;
//     if (this.quoteForm.get('doors')?.valid) completedFields++;
//     if (this.quoteForm.get('windows')?.valid) completedFields++;
//     if (this.quoteForm.get('area')?.valid) completedFields++;
//     if (this.quoteForm.get('floors')?.valid) completedFields++;
//     if (this.quoteForm.get('isGated')?.valid) completedFields++;
//     if (this.quoteForm.get('occupied')?.valid) completedFields++;

//     // Check Coverage Details
//     if (this.quoteForm.get('sumInsuredHouse')?.valid) completedFields++;
//     if (this.quoteForm.get('sumInsuredContents')?.valid) completedFields++;
//     if (this.quoteForm.get('deductibles')?.valid) completedFields++;
//     if (this.quoteForm.get('policyDuration')?.valid) completedFields++;

//     // Check if at least one fire safety measure is selected
//     const hasFireMeasure = this.fireMeasures.some(measure => 
//       this.quoteForm.get(measure.id)?.value === true
//     );
//     if (hasFireMeasure) completedFields++;

//     // Check if at least one burglary feature is selected
//     const hasBurglaryMeasure = this.burglaryMeasures.some(measure => 
//       this.quoteForm.get(measure.id)?.value === true
//     );
//     if (hasBurglaryMeasure) completedFields++;

//     // Calculate progress percentage
//     this.progress = Math.round((completedFields / totalRequiredFields) * 100);
//   }

//   loadQuoteIfEditing(): void {
//     this.route.queryParams.subscribe(params => {
//       if (params['id']) {
//         this.quotesService.getQuoteById(+params['id']).subscribe(quote => {
//           if (quote) {
//             this.currentQuoteId = quote.id;
//             this.isEditMode = true;
//             this.patchFormValues(quote);
//           }
//         });
//       }
//     });
//   }

//   patchFormValues(quote: Quote): void {
//     // Basic fields
//     this.quoteForm.patchValue({
//       fullName: quote.customerName,
//       email: quote.email,
//       phone: quote.phone,
//       // Map other fields from quote to form fields
//       // You'll need to adjust this based on your Quote model structure
//     });

//     // Handle fire safety measures
//     this.fireMeasures.forEach(measure => {
//       if (quote.fireSafetyMeasures?.includes(measure.label)) {
//         this.quoteForm.get(measure.id)?.setValue(true);
//       }
//     });
    
//     // Handle burglary features
//     this.burglaryMeasures.forEach(measure => {
//       if (quote.securityFeatures?.includes(measure.label)) {
//         this.quoteForm.get(measure.id)?.setValue(true);
//       }
//     });
//   }

//   formatDate(date: Date | string): string {
//     if (!date) return '';
//     const d = new Date(date);
//     return d.toISOString().split('T')[0];
//   }

//   onSubmit(): void {
//     if (this.quoteForm.valid) {
//         const userId = this.authService.getCurrentUserId();
//         if (!userId) {
//             this.authService.logout();
//             return;
//         }
//         const formValue = this.quoteForm.value;
        
//         // Prepare the security features and fire safety measures
//         const securityFeatures = this.burglaryMeasures
//           .filter(measure => formValue[measure.id])
//           .map(measure => measure.label);
          
//         const fireSafetyMeasures = this.fireMeasures
//           .filter(measure => formValue[measure.id])
//           .map(measure => measure.label);
        
//         const quoteData: Quote = {
//             id: this.isEditMode && this.currentQuoteId ? this.currentQuoteId : 0,
//             user: { id: userId },
//             customerName: formValue.fullName,
//             email: formValue.email,
//             phone: formValue.phone,
//             address: `${formValue.address1} ${formValue.address2 || ''}`,
//             propertyType: formValue.propertyType,
//             propertyAddress: `${formValue.address1} ${formValue.address2 || ''}`,
//             propertyCity: formValue.city,
//             propertyState: formValue.state,
//             propertyZip: formValue.zip,
//             constructionType: formValue.constructionType,
//             yearBuilt: new Date().getFullYear() - formValue.propertyAge,
//             squareFootage: formValue.area,
//             numRooms: formValue.rooms,
//             numDoors: formValue.doors,
//             numWindows: formValue.windows,
//             numFloors: formValue.floors,
//             isOccupiedFullTime: formValue.occupied === 'yes',
//             isGatedCommunity: formValue.isGated === 'yes',
//             securityFeatures: securityFeatures,
//             fireSafetyMeasures: fireSafetyMeasures,
//             sumInsuredHouse: formValue.sumInsuredHouse,
//             sumInsuredContents: formValue.sumInsuredContents,
//             deductible: formValue.deductibles,
//             policyDuration: formValue.policyDuration,
//             status: 'Submitted',
//             insuranceType: 'both',
//             createdAt: new Date(),
//             updatedAt: new Date()
//         };
        
//         console.log('Final quote data being sent:', quoteData);
        
//         const operation = this.isEditMode && this.currentQuoteId ?
//             this.quotesService.updateQuote(this.currentQuoteId, quoteData) :
//             this.quotesService.createQuote(quoteData);
            
//         operation.subscribe({
//             next: (response) => {
//                 console.log('Operation successful:', response);
//                 this.router.navigate(['/my-quotes']);
//             },
//             error: (err) => {
//                 console.error('Detailed error:', err);
//                 if (err.status === 403) {
//                     this.authService.logout();
//                 }
//             }
//         });
//     } else {
//         this.markFormGroupTouched(this.quoteForm);
//     }
//   }
  
//   private showSuccessAlert(message: string): void {
//     // You can replace this with a proper toast/notification system
//     alert(message);
//   }
  
//   private showErrorAlert(message: string): void {
//     alert(message);
//   }

//   getFormErrors(): any {
//     const errors: any = {};
//     Object.keys(this.quoteForm.controls).forEach(key => {
//       const control = this.quoteForm.get(key);
//       if (control?.errors) {
//         errors[key] = control.errors;
//       }
//     });
//     return errors;
//   }

//   markFormGroupTouched(formGroup: FormGroup) {
//     Object.values(formGroup.controls).forEach(control => {
//       control.markAsTouched();
//       if (control instanceof FormGroup) {
//         this.markFormGroupTouched(control);
//       }
//     });
//   }

//   saveAsDraft(): void {
//     const formValue = this.quoteForm.value;
    
//     // Similar to onSubmit but with Draft status
//     const securityFeatures = this.burglaryMeasures
//       .filter(measure => formValue[measure.id])
//       .map(measure => measure.label);
      
//     const fireSafetyMeasures = this.fireMeasures
//       .filter(measure => formValue[measure.id])
//       .map(measure => measure.label);
    
//     const quoteData: Partial<Quote> = {
//       id: this.isEditMode && this.currentQuoteId ? this.currentQuoteId : 0,
//       user: { id: this.authService.getCurrentUserId() },
//       customerName: formValue.fullName,
//       email: formValue.email,
//       phone: formValue.phone,
//       // Include all other fields as needed
//       securityFeatures: securityFeatures,
//       fireSafetyMeasures: fireSafetyMeasures,
//       status: 'Draft',
//       createdAt: new Date(),
//       updatedAt: new Date()
//     };

//     if (this.isEditMode && this.currentQuoteId) {
//       this.quotesService.updateQuote(this.currentQuoteId, quoteData as Quote).subscribe({
//         next: () => {
//           this.showSuccessAlert('Quote saved as draft!');
//           this.router.navigate(['/my-quotes']);
//         },
//         error: (err) => {
//           console.error('Error saving draft:', err);
//           this.showErrorAlert('Failed to save draft. Please try again.');
//         }
//       });
//     } else {
//       this.quotesService.createQuote(quoteData as Quote).subscribe({
//         next: () => {
//           this.showSuccessAlert('Quote saved as draft!');
//           this.router.navigate(['/my-quotes']);
//         },
//         error: (err) => {
//           console.error('Error saving draft:', err);
//           this.showErrorAlert('Failed to save draft. Please try again.');
//         }
//       });
//     }
//   }
// }

//thsi is new-quote.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { QuoteService } from '../../services/quote.service';
import { Quote } from '../../models/quote.model';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-new-quote',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './new-quote.component.html',
  styleUrls: ['./new-quote.component.css']
})
export class NewQuoteComponent implements OnInit {
  quoteForm!: FormGroup;
  isEditMode = false;
  currentQuoteId: number | null = null;
  progress = 0; // Progress percentage
  calculatedPremium: number = 0;

  // Multi-step form properties
  currentStep = 1;
  totalSteps = 4;
  stepTitles = [
    'Contact Details',
    'Property Details',
    'Coverage Details',
    'Security Measures'
  ];

  // Define security measures for checkboxes
  fireMeasures = [
    { id: 'fireExtinguishers', label: 'Fire Extinguishers' },
    { id: 'smokeDetectors', label: 'Smoke Detectors' },
    { id: 'sprinklerSystem', label: 'Sprinkler System' },
    { id: 'fireAlarmSystem', label: 'Fire Alarm System' },
    { id: 'fireEscapeRoutes', label: 'Fire Escape Routes' }
  ];

  burglaryMeasures = [
    { id: 'alarmSystem', label: 'Alarm System' },
    { id: 'securityCameras', label: 'Security Cameras' },
    { id: 'deadbolts', label: 'Deadbolts' },
    { id: 'barsOnWindows', label: 'Bars on Windows' },
    { id: 'cctvCameras', label: 'CCTV Cameras' },
    { id: 'securityGuards', label: 'Security Guards' },
    { id: 'burglarAlarmSystem', label: 'Burglar Alarm System' },
    { id: 'motionSensorLights', label: 'Motion Sensor Lights' },
    { id: 'strongLocks', label: 'Strong Locks & Reinforced Doors' }
  ];
  
  constructor(
    private fb: FormBuilder,
    private quotesService: QuoteService,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.loadQuoteIfEditing();
    this.updateProgress(); // Initialize progress
  }

  initializeForm(): void {
    // Create form controls for fire measures
    const fireMeasuresControls: Record<string, any> = {};
    this.fireMeasures.forEach(measure => {
      fireMeasuresControls[measure.id] = [false];
    });

    // Create form controls for burglary measures
    const burglaryMeasuresControls: Record<string, any> = {};
    this.burglaryMeasures.forEach(measure => {
      burglaryMeasuresControls[measure.id] = [false];
    });

    this.quoteForm = this.fb.group({
      // Contact Details
      fullName: ['', [Validators.required, Validators.minLength(2)]],
      dob: ['', Validators.required],
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10,15}$/)]],
      email: ['', [Validators.required, Validators.email]],
      address1: ['', [Validators.required]],
      address2: [''],
      country: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      zip: ['', [Validators.required, Validators.pattern(/^[0-9]{5,10}$/)]],
      
      // Property Details
      propertyAge: [null, [Validators.required, Validators.min(0)]],
      constructionType: ['', Validators.required],
      propertyType: ['', Validators.required],
      rooms: [null, [Validators.required, Validators.min(1)]],
      doors: [null, [Validators.required, Validators.min(1)]],
      windows: [null, [Validators.required, Validators.min(1)]],
      area: [null, [Validators.required, Validators.min(100)]],
      floors: [null, [Validators.required, Validators.min(1)]],
      isGated: ['', Validators.required],
      occupied: ['', Validators.required],
      
      // Coverage Details
      sumInsuredHouse: [null, [Validators.required, Validators.min(10000)]],
      sumInsuredContents: [null, [Validators.required, Validators.min(5000)]],
      deductibles: [null, [Validators.required, Validators.min(0)]],
      policyDuration: ['', Validators.required],
      
      // Security Measures - Fire Protection
      ...fireMeasuresControls,
      
      // Security Measures - Burglary Protection
      ...burglaryMeasuresControls,

      // Status control
      status: ['Draft']
    });

    // Add form field change listeners for progress tracking
    this.setupFormListeners();
  }

  private setupFormListeners(): void {
    this.quoteForm.valueChanges.subscribe(() => {
      this.updateProgress();
      this.updatePremium();
    });
  }

  updatePremium(): void {
    const formValue = this.quoteForm.value;
    
    const quoteData: Partial<Quote> = {
        sumInsuredHouse: formValue.sumInsuredHouse,
        sumInsuredContents: formValue.sumInsuredContents,
        yearBuilt: formValue.propertyAge ? new Date().getFullYear() - formValue.propertyAge : undefined,
        constructionType: formValue.constructionType,
        propertyType: formValue.propertyType,
        squareFootage: formValue.area,
        numRooms: formValue.rooms,
        numFloors: formValue.floors,
        isGatedCommunity: formValue.isGated === 'yes',
        isOccupiedFullTime: formValue.occupied === 'yes',
        fireSafetyMeasures: this.fireMeasures
            .filter(measure => formValue[measure.id])
            .map(measure => measure.label),
        securityFeatures: this.burglaryMeasures
            .filter(measure => formValue[measure.id])
            .map(measure => measure.label),
        country: formValue.country,
        deductible: formValue.deductibles,
        policyDuration: formValue.policyDuration
    };

    this.quotesService.calculatePremiumOnServer(quoteData).subscribe({
        next: (premium) => {
            this.calculatedPremium = premium;
        },
        error: (err) => {
            console.error('Error calculating premium:', err);
        }
    });
}

  // Navigation methods for multi-step form
  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      // Validation check for the current step
      if (this.isCurrentStepValid()) {
        this.currentStep++;
        window.scrollTo(0, 0);
      } else {
        this.markCurrentStepTouched();
      }
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
      window.scrollTo(0, 0);
    }
  }

  isCurrentStepValid(): boolean {
    const stepControls = this.getControlsForStep(this.currentStep);
    return stepControls.every(controlName => {
      const control = this.quoteForm.get(controlName);
      return control?.valid || !control?.validator;
    });
  }

  markCurrentStepTouched(): void {
    const stepControls = this.getControlsForStep(this.currentStep);
    stepControls.forEach(controlName => {
      const control = this.quoteForm.get(controlName);
      if (control) {
        control.markAsTouched();
      }
    });
  }

  getControlsForStep(step: number): string[] {
    switch (step) {
      case 1: // Contact Details
        return ['fullName', 'dob', 'phone', 'email', 'address1', 'country', 'state', 'city', 'zip'];
      case 2: // Property Details
        return ['propertyAge', 'constructionType', 'propertyType', 'rooms', 
                'doors', 'windows', 'area', 'floors', 'isGated', 'occupied'];
      case 3: // Coverage Details
        return ['sumInsuredHouse', 'sumInsuredContents', 'deductibles', 'policyDuration'];
      case 4: // Security Measures
        return [
          ...this.fireMeasures.map(m => m.id),
          ...this.burglaryMeasures.map(m => m.id)
        ];
      default:
        return [];
    }
  }

  getStepCompletionPercentage(step: number): number {
    const stepControls = this.getControlsForStep(step);
    const validControls = stepControls.filter(controlName => {
      const control = this.quoteForm.get(controlName);
      return control?.valid;
    });
    
    return Math.round((validControls.length / stepControls.length) * 100);
  }

  updateProgress(): void {
    const totalRequiredFields = 24; // Total number of required fields
    let completedFields = 0;

    // Check Contact Details
    if (this.quoteForm.get('fullName')?.valid) completedFields++;
    if (this.quoteForm.get('dob')?.valid) completedFields++;
    if (this.quoteForm.get('phone')?.valid) completedFields++;
    if (this.quoteForm.get('email')?.valid) completedFields++;
    if (this.quoteForm.get('address1')?.valid) completedFields++;
    if (this.quoteForm.get('country')?.valid) completedFields++;
    if (this.quoteForm.get('state')?.valid) completedFields++;
    if (this.quoteForm.get('city')?.valid) completedFields++;
    if (this.quoteForm.get('zip')?.valid) completedFields++;

    // Check Property Details
    if (this.quoteForm.get('propertyAge')?.valid) completedFields++;
    if (this.quoteForm.get('constructionType')?.valid) completedFields++;
    if (this.quoteForm.get('propertyType')?.valid) completedFields++;
    if (this.quoteForm.get('rooms')?.valid) completedFields++;
    if (this.quoteForm.get('doors')?.valid) completedFields++;
    if (this.quoteForm.get('windows')?.valid) completedFields++;
    if (this.quoteForm.get('area')?.valid) completedFields++;
    if (this.quoteForm.get('floors')?.valid) completedFields++;
    if (this.quoteForm.get('isGated')?.valid) completedFields++;
    if (this.quoteForm.get('occupied')?.valid) completedFields++;

    // Check Coverage Details
    if (this.quoteForm.get('sumInsuredHouse')?.valid) completedFields++;
    if (this.quoteForm.get('sumInsuredContents')?.valid) completedFields++;
    if (this.quoteForm.get('deductibles')?.valid) completedFields++;
    if (this.quoteForm.get('policyDuration')?.valid) completedFields++;

    // Check if at least one fire safety measure is selected
    const hasFireMeasure = this.fireMeasures.some(measure => 
      this.quoteForm.get(measure.id)?.value === true
    );
    if (hasFireMeasure) completedFields++;

    // Check if at least one burglary feature is selected
    const hasBurglaryMeasure = this.burglaryMeasures.some(measure => 
      this.quoteForm.get(measure.id)?.value === true
    );
    if (hasBurglaryMeasure) completedFields++;

    // Calculate progress percentage
    if(this.progress==0){
    this.progress = Math.round((completedFields / totalRequiredFields) * 100);
    }else{
      this.progress = Math.round((completedFields / totalRequiredFields) * 100)-4;

    }
  }

  // In new-quote.component.ts
  loadQuoteIfEditing(): void {
    this.route.params.subscribe(params => {
      const id = params['id']; // This will be undefined for new quotes
      if (id) {
        this.isEditMode = true;
        this.currentQuoteId = +id;
        this.quotesService.getQuoteById(+id).subscribe(quote => {
          if (quote) {
            this.patchFormValues(quote);
          }
        });
      } else {
        this.isEditMode = false;
      }
    });
  }

  patchFormValues(quote: Quote): void {
    // Basic fields
    this.quoteForm.patchValue({
      fullName: quote.customerName,
      email: quote.email,
      phone: quote.phone,
      address1: quote.address?.split(',')[0]?.trim() || '',
      address2: quote.address?.split(',')[1]?.trim() || '',
      country: quote.country,
      state: quote.propertyState,
      city: quote.propertyCity,
      zip: quote.propertyZip,
      propertyAge: quote.yearBuilt ? new Date().getFullYear() - quote.yearBuilt : null,
      constructionType: quote.constructionType,
      propertyType: quote.propertyType,
      rooms: quote.numRooms,
      doors: quote.numDoors,
      windows: quote.numWindows,
      area: quote.squareFootage,
      floors: quote.numFloors,
      isGated: quote.isGatedCommunity ? 'yes' : 'no',
      occupied: quote.isOccupiedFullTime ? 'yes' : 'no',
      sumInsuredHouse: quote.sumInsuredHouse,
      sumInsuredContents: quote.sumInsuredContents,
      deductibles: quote.deductible,
      policyDuration: quote.policyDuration,
      status: quote.status
    });

    // Handle fire safety measures
    this.fireMeasures.forEach(measure => {
      if (quote.fireSafetyMeasures?.includes(measure.label)) {
        this.quoteForm.get(measure.id)?.setValue(true);
      }
    });
    
    // Handle burglary features
    this.burglaryMeasures.forEach(measure => {
      if (quote.securityFeatures?.includes(measure.label)) {
        this.quoteForm.get(measure.id)?.setValue(true);
      }
    });
  }

  onSubmit(): void {
    const formValue = this.quoteForm.value;
    console.log('Status in onSubmit:', formValue.status);
  
    if (this.quoteForm.valid) {
      const formValue = this.quoteForm.value;
      
      // Get the status from the form value
      // This will respect the 'Draft' status set by saveAsDraft()
      const status = formValue.status || 'Submitted';
      
      const userId = this.authService.getCurrentUserId();
      if (!userId) {
        this.authService.logout();
        return;
      }
      
      // Prepare the security features and fire safety measures
      const securityFeatures = this.burglaryMeasures
        .filter(measure => formValue[measure.id])
        .map(measure => measure.label);
        
      const fireSafetyMeasures = this.fireMeasures
        .filter(measure => formValue[measure.id])
        .map(measure => measure.label);
      
      // Create a complete Quote object with all required fields
      const quoteData: Quote = {
        id: this.isEditMode && this.currentQuoteId ? this.currentQuoteId : 0, // Temporary ID for new quotes
        user: { id: userId },
        customerName: formValue.fullName,
        email: formValue.email,
        
        premium: this.calculatedPremium,
        phone: formValue.phone,
        address: `${formValue.address1} ${formValue.address2 || ''}`.trim(),
        country: formValue.country || '', // Ensure country is provided
        propertyType: formValue.propertyType,
        propertyAddress: `${formValue.address1} ${formValue.address2 || ''}`.trim(),
        propertyCity: formValue.city,
        propertyState: formValue.state,
        propertyZip: formValue.zip,
        constructionType: formValue.constructionType,
        yearBuilt: new Date().getFullYear() - formValue.propertyAge,
        squareFootage: formValue.area,
        numRooms: formValue.rooms,
        numDoors: formValue.doors,
        numWindows: formValue.windows,
        numFloors: formValue.floors,
        isOccupiedFullTime: formValue.occupied === 'yes',
        securityFeatures: securityFeatures,
        fireSafetyMeasures: fireSafetyMeasures,
        sumInsuredHouse: formValue.sumInsuredHouse,
        sumInsuredContents: formValue.sumInsuredContents,
        deductible: formValue.deductibles,
        policyDuration: formValue.policyDuration,
        status: status, // Use the status from form value
        insuranceType: 'both',
        createdAt: this.isEditMode ? new Date() : new Date(), // Use existing date for edits
        updatedAt: new Date(),
        // Set default values for other required properties
        numBathrooms: 1, // Default value or get from form if available
        hasNearbyFireStation: false,
        otherFireSafetyMeasures: '',
        otherSecurityFeatures: '',
        hasHighValueItems: false,
        highValueItemsList: '',
      };
  
      // Add optional properties if they exist in the form
      if (formValue.isGated !== undefined) {
        quoteData.isGatedCommunity = formValue.isGated === 'yes';
      }
  
      console.log('Final quote data being sent:', quoteData);
      
      const operation = this.isEditMode && this.currentQuoteId ?
      this.quotesService.updateQuote(this.currentQuoteId, quoteData) :
      this.quotesService.createQuote(quoteData);
  
      operation.subscribe({
        next: (response) => {
          console.log('Quote saved with status:', response.status);
          console.log('Quote saved with premium:', response.premium);
          this.showSuccessAlert(`Quote ${this.isEditMode ? 'updated' : 'created'} successfully!`);
          this.router.navigate(['/my-quotes']);
        },
        error: (err) => {
          console.error('Error saving premium:', err);
          this.showErrorAlert(`Failed to ${this.isEditMode ? 'update' : 'create'} quote. Please try again.`);
          if (err.status === 403) {
            this.authService.logout();
          }
        }
      });
    } else {
      this.markFormGroupTouched(this.quoteForm);
      this.showErrorAlert('Please fill all required fields correctly.');
    }
  }
  submitQuote(): void {
    this.quoteForm.patchValue({ status: 'Submitted' });
    this.onSubmit();
  }
  
  saveAsDraft(): void {
    console.log('Status before patchValue:', this.quoteForm.value.status);
    this.quoteForm.patchValue({ status: 'Draft' });
    console.log('Status after patchValue:', this.quoteForm.value.status);
    this.onSubmit();
  }


  private showSuccessAlert(message: string): void {
    // Replace with your preferred notification system
    alert(message);
  }
  
  private showErrorAlert(message: string): void {
    // Replace with your preferred notification system
    alert(message);
  }

  getFormErrors(): any {
    const errors: any = {};
    Object.keys(this.quoteForm.controls).forEach(key => {
      const control = this.quoteForm.get(key);
      if (control?.errors) {
        errors[key] = control.errors;
      }
    });
    return errors;
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}