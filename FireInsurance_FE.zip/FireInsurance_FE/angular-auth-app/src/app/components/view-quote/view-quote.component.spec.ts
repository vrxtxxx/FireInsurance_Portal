// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { ViewQuoteComponent } from './view-quote.component';

// describe('ViewQuoteComponent', () => {
//   let component: ViewQuoteComponent;
//   let fixture: ComponentFixture<ViewQuoteComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       imports: [ViewQuoteComponent]
//     })
//     .compileComponents();

//     fixture = TestBed.createComponent(ViewQuoteComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewQuoteComponent } from './view-quote.component';
import { ActivatedRoute, Router } from '@angular/router';
import { QuoteService } from '../../services/quote.service';
import { of } from 'rxjs';
import { Quote, QuoteStatus } from '../../models/quote.model';
 
describe('ViewQuoteComponent', () => {
  let component: ViewQuoteComponent;
  let fixture: ComponentFixture<ViewQuoteComponent>;
  let mockQuoteService: any;
  let mockRouter: any;
  let mockActivatedRoute: any;

  const mockQuote: Quote = {
    id: 1,
    country: 'USA',
    user: { id: 1 },
    insuranceType: 'both',
    customerName: 'Test User',
    email: 'test@example.com',
    phone: '1234567890',
    address: '123 Test St',
    propertyType: 'House',
    propertyAddress: '123 Test St',
    propertyCity: 'Test City',
    propertyState: 'TS',
    propertyZip: '12345',
    constructionType: 'Brick',
    yearBuilt: 2000,
    squareFootage: 2000,
    numRooms: 4,
    numDoors: 10,
    numWindows: 12,
    numFloors: 2,
    isOccupiedFullTime: true,
    securityFeatures: ['Alarm'],
    fireSafetyMeasures: ['Smoke Detectors'],
    deductible: 500,
    policyDuration: '1',
    status: 'Draft' as QuoteStatus,
    createdAt: new Date(),
    updatedAt: new Date(),
    premium: 1200
  };

  beforeEach(async () => {
    mockQuoteService = {
      getQuoteById: jest.fn()
    };
    mockRouter = {
      navigate: jest.fn()
    };
    mockActivatedRoute = {
      snapshot: {
        paramMap: {
          get: jest.fn().mockReturnValue('1')
        }
      }
    };

    await TestBed.configureTestingModule({
      imports: [ViewQuoteComponent],
      providers: [
        { provide: QuoteService, useValue: mockQuoteService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ViewQuoteComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load quote on init', () => {
    mockQuoteService.getQuoteById.mockReturnValue(of(mockQuote));
    
    component.ngOnInit();
    
    expect(mockQuoteService.getQuoteById).toHaveBeenCalledWith(1);
    expect(component.quote).toEqual(mockQuote);
  });

  it('should handle error when loading quote', () => {
    mockQuoteService.getQuoteById.mockReturnValue(of(null));
    
    component.ngOnInit();
    
    expect(component.error).toBe('Failed to load quote');
  });

  it('should go back to quotes', () => {
    component.goBack();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['/my-quotes']);
  });
});