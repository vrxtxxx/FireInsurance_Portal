// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { QuoteService } from '../../services/quote.service';
// import { Quote } from '../../models/quote.model';

// @Component({
//   selector: 'app-view-quote',
//   templateUrl: './view-quote.component.html',
//   styleUrls: ['./view-quote.component.css']
// })
// export class ViewQuoteComponent implements OnInit {
//   quote: Quote | null = null;
//   loading = true;
//   error: string | null = null;

//   constructor(
//     private route: ActivatedRoute,
//     private quoteService: QuoteService
//   ) { }

//   ngOnInit(): void {
//     const id = this.route.snapshot.paramMap.get('id');
//     if (id) {
//       this.loadQuote(+id);
//     } else {
//       this.error = 'Invalid quote ID';
//       this.loading = false;
//     }
//   }

//   loadQuote(id: number): void {
//     this.loading = true;
//     this.error = null;
    
//     this.quoteService.getQuoteById(id).subscribe({
//       next: (quote) => {
//         this.quote = quote;
//         this.loading = false;
//       },
//       error: (err) => {
//         this.error = 'Failed to load quote';
//         this.loading = false;
//         console.error('Error loading quote:', err);
//       }
//     });
//   }

//   getStatusClass(status: string): string {
//     switch (status) {
//       case 'Draft': return 'badge-secondary';
//       case 'Submitted': return 'badge-primary';
//       case 'Bound': return 'badge-success';
//       default: return 'badge-light';
//     }
//   }
// }

//view-quote.component.ts
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuoteService } from '../../services/quote.service';
import { Quote } from '../../models/quote.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas'; 
import { Tab } from 'bootstrap';

@Component({
  selector: 'app-view-quote',
  templateUrl: './view-quote.component.html',
  styleUrls: ['./view-quote.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class ViewQuoteComponent implements OnInit {
  quote: Quote | null = null;
  isLoading: boolean = false;
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private quoteService: QuoteService
  ) {}
  ngAfterViewInit() {
    // Initialize tabs
    const tabEls = document.querySelectorAll('button[data-bs-toggle="tab"]');
    tabEls.forEach(tabEl => {
      new Tab(tabEl);
    });
  }
  editQuote(): void {
    if (this.quote) {
      this.router.navigate(['/quotes', this.quote.id, 'edit']);
    }
  }
  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
  this.quoteService.getQuoteById(id).subscribe((data) => {
    console.log('Loaded quote data:', data.country); 
    if (data) {
      this.quote = data;
    } else {
      this.error = 'Failed to load quote';
    }
  });
  }
  // Add this new method to bind the quote to a policy
  bindToPolicy(): void {
    if (!this.quote) return;
  
    if (confirm('Are you sure you want to bind this quote to a policy?')) {
      this.isLoading = true;
      
      this.quoteService.bindQuote(this.quote.id).subscribe({
        next: (updatedQuote) => {
          this.quote = updatedQuote;
          this.isLoading = false;
          alert('Quote successfully bound to policy!');
        },
        error: (err) => {
          this.isLoading = false;
          this.error = err.message || 'Failed to bind quote to policy';
          console.error('Error binding quote:', err);
        }
      });
    }
  }
  // Update the statusBadgeClass to include 'Bound' status
  get statusBadgeClass(): string {
    switch(this.quote?.status) {
      case 'Draft': return 'bg-warning';
      case 'Submitted': return 'bg-primary';
      case 'Approved': return 'bg-success';
      case 'Bound': return 'bg-success'; // Same as Approved
      case 'Rejected': return 'bg-danger';
      default: return 'bg-secondary';
    }
  }  
  loadQuote(id: number): void {
    this.isLoading = true;
    this.quoteService.getQuoteById(id).subscribe({
      next: (quote) => {
        this.quote = quote;
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        if (err.status === 403) {
          this.error = 'You are not authorized to view this quote';
        } else {
          this.error = 'Failed to load quote';
        }
        console.error('Error loading quote:', err);
      }
    });
  }
  
  downloadAsPDF(): void {
    const element = document.getElementById('quote-details') as HTMLElement;
    
    // Add some options for better quality
    const options = {
      scale: 2, // Increase quality
      useCORS: true, // For external resources
      logging: false // Disable console logging
    };
  
    html2canvas(element, options).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      // Add some margins (10mm on each side)
      const margin = 10;
      const width = pdfWidth - 2 * margin;
      const height = (imgProps.height * width) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', margin, margin, width, height);
      pdf.save(`quote-${this.quote?.id}.pdf`);
    });
  }

  printQuote(): void {
    window.print();
  }

  goBack(): void {
    this.router.navigate(['/my-quotes']);
  }


  
}
