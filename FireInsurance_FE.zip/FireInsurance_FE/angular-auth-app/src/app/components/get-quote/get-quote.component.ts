import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-get-quote',
  templateUrl: './get-quote.component.html',
  styleUrls: ['./get-quote.component.css']
})
export class GetQuoteComponent {
  constructor(private router: Router) {}

  navigateToNewQuote(): void {
    this.router.navigate(['/new-quote']);
  }
}