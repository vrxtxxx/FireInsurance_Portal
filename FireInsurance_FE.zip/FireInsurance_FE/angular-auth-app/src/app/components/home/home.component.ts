import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-landing',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  standalone: true,
  imports: [CommonModule]
})
export class LandingComponent {
  constructor(private router: Router) {}

  navigateToLogin(): void {
    this.router.navigate(['/login']);
  }
  
  // Additional methods for any new interactive elements
  
  learnMore() {
    this.router.navigate(['/login']);
  }
  
  selectCountry(country: string): void {
    console.log(`Selected country: ${country}`);
    // Implement country selection logic
  }
}