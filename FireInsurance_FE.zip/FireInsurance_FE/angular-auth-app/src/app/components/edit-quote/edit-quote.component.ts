import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuoteService } from '../../services/quote.service';
import { Quote } from '../../models/quote.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-edit-quote',
  templateUrl: './edit-quote.component.html',
  styleUrls: ['./edit-quote.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class EditQuoteComponent implements OnInit {
  quote: Quote | null = null;
  isLoading: boolean = false;
  isSaving: boolean = false;
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private quoteService: QuoteService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.loadQuote(Number(id));
    } else {
      this.error = 'Invalid quote ID';
    }
  }

  loadQuote(id: number): void {
    this.isLoading = true;
    this.quoteService.getQuoteById(id).subscribe({
      next: (quote) => {
        console.log('Full quote data:', quote); // Add this line
        this.quote = quote;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading quote:', err);
        this.isLoading = false;
      }
    });
  }
    
  saveQuote(): void {
    if (!this.quote) return;
    
    // Set status to 'Submitted' when saving
    this.quote.status = 'Submitted';
    
    this.isSaving = true;
    this.quoteService.updateQuote(this.quote.id, this.quote).subscribe({
        next: (updatedQuote) => {
            this.quote = updatedQuote;
            this.isSaving = false;
            this.router.navigate(['/view-quote', this.quote.id]);
        },
        error: (err) => {
            this.isSaving = false;
            if (err.status === 403) {
                this.error = 'You are not authorized to update this quote';
            } else {
                this.error = 'Failed to save quote';
            }
            console.error('Error saving quote:', err);
        }
    });
  }

  cancel(): void {
    if (this.quote) {
      this.router.navigate(['/view-quote', this.quote.id]);
    } else {
      this.router.navigate(['/my-quotes']);
    }
  }
}