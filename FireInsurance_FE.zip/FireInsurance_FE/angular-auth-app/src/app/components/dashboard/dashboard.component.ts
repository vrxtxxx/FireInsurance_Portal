import { Component, AfterViewInit, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Chart, registerables } from 'chart.js';
import { AuthService } from '../../services/auth.service';
import { QuoteService } from '../../services/quote.service';

interface StatusCounts {
  Draft: number;
  Submitted: number;
  Approved: number;
  Bound: number;
  Rejected: number;
  [key: string]: number; // Add index signature
}

interface TrendData {
  labels: string[];
  statusData: {
    [status: string]: number[];
  };
}

interface DashboardStats {
  totalQuotes: number;
  statusCounts: StatusCounts;
  weeklyData: TrendData;
  monthlyData: TrendData;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule], // Make sure CommonModule is imported
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  stats: {title: string, value: number}[] = [];
  currentView: 'weekly' | 'monthly' = 'weekly';
  isLoading: boolean = true;
  private pieChart?: Chart;
  private barChart?: Chart;

  // Define status colors with proper typing
  private statusColors: {[key in keyof StatusCounts]: string} = {
    Draft: '#FFCE56',
    Submitted: '#36A2EB',
    Approved: '#4BC0C0',
    Bound: '#9966FF',
    Rejected: '#FF6384'
  };

  constructor(
    private authService: AuthService,
    private quoteService: QuoteService
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  ngAfterViewInit() {
    Chart.register(...registerables);
  }

  loadDashboardData(): void {
    this.quoteService.getDashboardStats().subscribe({
      next: (data: DashboardStats) => {
        this.stats = [
          { title: 'Total Quotes', value: data.totalQuotes },
          { title: 'Draft', value: data.statusCounts.Draft },
          { title: 'Submitted', value: data.statusCounts.Submitted },
          { title: 'Bound', value: data.statusCounts.Bound }
        ];

        this.renderPieChart(data.statusCounts);
        this.renderBarChart(this.currentView === 'weekly' ? data.weeklyData : data.monthlyData);
        this.isLoading = false;
      },
      error: (err: any) => {
        console.error('Error loading dashboard data:', err);
        this.isLoading = false;
      }
    });
  }

  toggleView(view: 'weekly' | 'monthly'): void {
    this.currentView = view;
    this.quoteService.getDashboardStats().subscribe({
      next: (data: DashboardStats) => {
        this.renderBarChart(view === 'weekly' ? data.weeklyData : data.monthlyData);
      },
      error: (err: any) => console.error('Error loading trend data:', err)
    });
  }

  renderPieChart(statusCounts: StatusCounts): void {
    const ctx = document.getElementById('statusDistributionChart') as HTMLCanvasElement;
    
    if (this.pieChart) {
      this.pieChart.destroy();
    }

    const labels = Object.keys(statusCounts).filter(k => k !== 'Other');
    const data = labels.map(label => statusCounts[label]);

    this.pieChart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: labels,
        datasets: [{
          data: data,
          backgroundColor: labels.map(label => this.statusColors[label]),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: 'Quote Status Distribution'
          }
        }
      }
    });
  }

  renderBarChart(trendData: TrendData): void {
    const ctx = document.getElementById('quoteTrendChart') as HTMLCanvasElement;
    
    if (this.barChart) {
      this.barChart.destroy();
    }

    // Take only the last 7 weeks
    const maxWeeksToShow = 7;
    const labels = trendData.labels.slice(-maxWeeksToShow); // Last 7 labels
    
    // Prepare limited status data (last 7 weeks for each status)
    const limitedStatusData: { [key: string]: number[] } = {};
    Object.keys(trendData.statusData).forEach(status => {
        limitedStatusData[status] = trendData.statusData[status].slice(-maxWeeksToShow);
    });

    // Create chart datasets
    const datasets = Object.keys(limitedStatusData).map(status => ({
      label: status,
      data: limitedStatusData[status],
      backgroundColor: this.statusColors[status],
      borderColor: this.statusColors[status],
      borderWidth: 1
    }));

    this.barChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels, // Only 7 weeks
        datasets: datasets
      },
      options: {
        responsive: true,
        scales: {
          x: {
            stacked: true,
          },
          y: {
            stacked: true,
            beginAtZero: true
          }
        },
        plugins: {
          title: {
            display: true,
            text: `Quote Trends (Last ${maxWeeksToShow} Weeks)`
          }
        }
      }
    });
}
}