//   import { Component, OnInit, HostListener } from '@angular/core';
//   import { Router } from '@angular/router';
//   import { CommonModule } from '@angular/common';
//   import { FormsModule } from '@angular/forms';
//   import { Quote } from '../../models/quote.model';
//   import { QuoteService } from '../../services/quote.service';
//   import { AuthService } from '../../services/auth.service';

//   @Component({
//     selector: 'app-my-quotes',
//     templateUrl: './my-quotes.component.html',
//     styleUrls: ['./my-quotes.component.css'],
//     standalone: true,
//     imports: [CommonModule, FormsModule]
//   })
//   export class MyQuotesComponent implements OnInit {
//     quotes: Quote[] = [];
//     filteredQuotes: Quote[] = [];
//     isLoading: boolean = false;
//     searchText = '';
//     statusFilter = 'All';
//     sortBy = 'createdAt';
//     sortOrder = 'desc';
//     activeDropdownId: number | null = null;
    
//     constructor(
//       public router: Router,
//       private quoteService: QuoteService,
//       private authService: AuthService
//     ) {}
    
//     @HostListener('document:click', ['$event'])
//     documentClick(event: MouseEvent) {
//       const clickedElement = event.target as HTMLElement;
//       if (!clickedElement.closest('.dropdown-action') && 
//           !clickedElement.closest('.dropdown-content')) {
//         this.activeDropdownId = null;
//       }
//     }
    
//     ngOnInit() {
//       console.log('Token exists:', !!this.authService.getToken());
//       console.log('User ID:', this.authService.getCurrentUserId());
      
//       const userId = this.authService.getCurrentUserId();
//       if (userId) {
//         this.loadQuotes(userId);
//       } else {
//         console.warn('No user ID found, redirecting to login');
//         this.router.navigate(['/login']);
//       }
//     }

//     loadQuotes(userId: number): void {
//       this.isLoading = true;
//       this.quoteService.getUserQuotes(userId).subscribe({
//         next: (quotes) => {
//           this.quotes = quotes.map(quote => ({
//             ...quote,
//             lastName: '',
//             propertyAddress: quote.address,
//             address: quote.address
//           }));
//           this.applyFilters();
//           this.isLoading = false;
//         },
//         error: (err) => {
//           console.error('Error loading quotes:', err);
//           this.isLoading = false;
//         }
//       });
//     }

//     applyFilters() {
//       let filtered = [...this.quotes];
      
//       if (this.searchText) {
//         const searchLower = this.searchText.toLowerCase();
//         filtered = filtered.filter(quote => 
//           quote.id.toString().includes(searchLower) ||
//           quote.customerName.toLowerCase().includes(searchLower) ||
//           quote.email.toLowerCase().includes(searchLower) ||
//           quote.address.toLowerCase().includes(searchLower)
//         );
//       }
      
//       if (this.statusFilter !== 'All') {
//         filtered = filtered.filter(quote => quote.status === this.statusFilter);
//       }
      
//       filtered.sort((a, b) => {
//         let comparison = 0;
        
//         if (this.sortBy === 'createdAt') {
//           const aTime = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
//           const bTime = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
//           comparison = aTime - bTime;
//         } else if (this.sortBy === 'premium') {
//           const aPremium = a.premium ?? 0;
//           const bPremium = b.premium ?? 0; 
//           comparison = aPremium - bPremium;
//         } else if (this.sortBy === 'id') {
//           comparison = a.id - b.id;
//         }
        
//         return this.sortOrder === 'asc' ? comparison : -comparison;
//       });
      
//       this.filteredQuotes = filtered;
//     }

//     toggleDropdown(event: Event, quoteId: number) {
//       event.preventDefault();
//       event.stopPropagation();
//       this.activeDropdownId = this.activeDropdownId === quoteId ? null : quoteId;
//     }

//     isDropdownOpen(quoteId: number): boolean {
//       return this.activeDropdownId === quoteId;
//     }

//     canEdit(status: string): boolean {
//       return ['Draft', 'Submitted'].includes(status);
//     }

//     canBind(status: string): boolean {
//       return status === 'Approved';
//     }

//     canDelete(status: string): boolean {
//       return ['Draft', 'Rejected'].includes(status);
//     }

//     viewQuote(id: number) {
//       this.router.navigate(['/quotes', id]);
//     }

//     // editQuote(id: number | 'new') {
//     //   if (id === 'new') {
//     //     this.router.navigate(['/new-quote',id,'edit']);
//     //   } else {
//     //     this.router.navigate(['/quotes', id, 'edit']);
//     //   }
//     // }
//   // In your component that has the editQuote method
//   // Replace the editQuote method with these two separate methods
// createNewQuote() {
//   this.router.navigate(['/new-quote', 'edit']);
// }

// editQuote(id: number | string) {
//   if (id === 'new') {
//     this.router.navigate(['/new-quote', 'edit']);
//   } else {
//     this.router.navigate(['/quotes', +id, 'edit']); // + converts to number
//   }
// }
//     bindQuote(id: number) {
//       console.log('Binding quote:', id);
//       alert(`Quote ${id} bound successfully!`);
//     }

//     deleteQuote(id: number) {
//       if (confirm('Are you sure you want to delete this quote?')) {
//         this.quoteService.deleteQuote(id).subscribe({
//           next: () => {
//             this.quotes = this.quotes.filter(quote => quote.id !== id);
//             this.applyFilters();
//             alert('Quote deleted successfully!');
//           },
//           error: (err) => {
//             console.error('Error deleting quote:', err);
//             alert('Failed to delete quote. Please try again.');
//           }
//         });
//       }
//     }
//   }

import { Component, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Quote } from '../../models/quote.model';
import { QuoteService } from '../../services/quote.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-my-quotes',
  templateUrl: './my-quotes.component.html',
  styleUrls: ['./my-quotes.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class MyQuotesComponent implements OnInit {
  quotes: Quote[] = [];
  filteredQuotes: Quote[] = [];
  displayedQuotes: Quote[] = [];
  isLoading: boolean = false;
  searchText = '';
  statusFilter = 'All';
  sortBy = 'createdAt';
  sortOrder = 'desc';
  activeDropdownId: number | null = null;
  
  // Pagination properties
  currentPage: number = 1;
  itemsPerPage: number = 5;
  totalPages: number = 1;
  
  constructor(
    public router: Router,
    private quoteService: QuoteService,
    private authService: AuthService
  ) {}
  
  @HostListener('document:click', ['$event'])
  documentClick(event: MouseEvent) {
    const clickedElement = event.target as HTMLElement;
    if (!clickedElement.closest('.dropdown-action') && 
        !clickedElement.closest('.dropdown-content')) {
      this.activeDropdownId = null;
    }
  }
  
  ngOnInit() {
    const userId = this.authService.getCurrentUserId();
    if (userId) {
      this.loadQuotes(userId);
    } else {
      this.router.navigate(['/login']);
    }
  }

  loadQuotes(userId: number): void {
    this.isLoading = true;
    this.quoteService.getUserQuotes(userId).subscribe({
      next: (quotes) => {
        this.quotes = quotes.map(quote => ({
          ...quote,
          lastName: '',
          propertyAddress: quote.address,
          address: quote.address
        }));
        this.applyFilters();
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading quotes:', err);
        this.isLoading = false;
      }
    });
  }

  applyFilters(): void {
    let filtered = [...this.quotes];
    
    if (this.searchText) {
      const searchLower = this.searchText.toLowerCase();
      filtered = filtered.filter(quote => 
        quote.id.toString().includes(searchLower) ||
        quote.customerName.toLowerCase().includes(searchLower) ||
        quote.email.toLowerCase().includes(searchLower) ||
        quote.address.toLowerCase().includes(searchLower)
      );
    }
    
    if (this.statusFilter !== 'All') {
      filtered = filtered.filter(quote => quote.status === this.statusFilter);
    }
    
    filtered.sort((a, b) => {
      let comparison = 0;
      
      if (this.sortBy === 'createdAt') {
        const aTime = a.createdAt instanceof Date ? a.createdAt.getTime() : new Date(a.createdAt).getTime();
        const bTime = b.createdAt instanceof Date ? b.createdAt.getTime() : new Date(b.createdAt).getTime();
        comparison = aTime - bTime;
      } else if (this.sortBy === 'premium') {
        const aPremium = a.premium ?? 0;
        const bPremium = b.premium ?? 0; 
        comparison = aPremium - bPremium;
      } else if (this.sortBy === 'id') {
        comparison = a.id - b.id;
      }
      
      return this.sortOrder === 'asc' ? comparison : -comparison;
    });
    
    this.filteredQuotes = filtered;
    this.totalPages = Math.ceil(this.filteredQuotes.length / this.itemsPerPage);
    this.updateDisplayedQuotes();
  }

  updateDisplayedQuotes(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.displayedQuotes = this.filteredQuotes.slice(startIndex, endIndex);
  }

  // Serial number for display
  getSerialNumber(index: number): number {
    return ((this.currentPage - 1) * this.itemsPerPage) + index + 1;
  }

  // Pagination controls
  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updateDisplayedQuotes();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updateDisplayedQuotes();
    }
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updateDisplayedQuotes();
    }
  }

  // Rest of your existing methods...
  toggleDropdown(event: Event, quoteId: number) {
    event.preventDefault();
    event.stopPropagation();
    this.activeDropdownId = this.activeDropdownId === quoteId ? null : quoteId;
  }

  isDropdownOpen(quoteId: number): boolean {
    return this.activeDropdownId === quoteId;
  }

  canEdit(status: string): boolean {
    return ['Draft', 'Submitted'].includes(status);
  }

  canDelete(status: string): boolean {
    return ['Draft', 'Rejected'].includes(status);
  }

  viewQuote(id: number) {
    this.router.navigate(['/quotes', id]);
  }

  createNewQuote() {
    this.router.navigate(['/new-quote', 'edit']);
  }

  editQuote(id: number) {
    this.router.navigate(['/quotes', id, 'edit']);
  }

  deleteQuote(id: number) {
    if (confirm('Are you sure you want to delete this quote?')) {
      this.quoteService.deleteQuote(id).subscribe({
        next: () => {
          this.quotes = this.quotes.filter(quote => quote.id !== id);
          this.applyFilters();
          alert('Quote deleted successfully!');
        },
        error: (err) => {
          console.error('Error deleting quote:', err);
          alert('Failed to delete quote. Please try again.');
        }
      });
    }
  }
  getDisplayEnd(): number {
    return Math.min(this.currentPage * this.itemsPerPage, this.filteredQuotes.length);
  }
}