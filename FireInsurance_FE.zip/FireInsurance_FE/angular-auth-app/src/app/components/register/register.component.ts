import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service'; // adjust path if needed
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {
  registerForm!: FormGroup;
  submitted = false;
  
  constructor(private formBuilder: FormBuilder, private authService: AuthService,private router: Router ) {}

  
  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      // phoneNumber: ['', Validators.required],
      country: ['', Validators.required],
      // company: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required]
    }, {
      validators: this.mustMatch('password', 'confirmPassword')
    });
  }
  
  // Custom validator to check if password and confirm password match
  mustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors['mustMatch']) {
        return;
      }

      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }
  
  // Convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls;
  }
  
  onSubmit() {
    this.submitted = true;
    console.log("Register button clicked!");
    
    if (this.registerForm.invalid) {
      return;
    }
  
    const payload = {
      username: `${this.f['firstName'].value} ${this.f['lastName'].value}`,
      email: this.f['email'].value,
      password: this.f['password'].value,
      firstName: this.f['firstName'].value,
      lastName: this.f['lastName'].value,
      country: this.f['country'].value,
    };
    
    console.log("Sending payload:", payload);
    
    this.authService.register(payload).subscribe({
      next: (res: string) => {  // Explicitly type as string
        console.log("Redirecting to login page...");

        alert(res);  // res is the plain text response
        this.registerForm.reset();
        this.submitted = false;
        this.router.navigate(['/login']);

      },
      error: (err) => {
        if (err.status === 409) {
          alert('Email already exists!');
        } else {
          // Handle parsing error specifically
          if (err.error && err.error.text) {
            alert(err.error.text);  // Access the text response from the error
          } else {
            alert('Something went wrong!');
          }
        }
      }
    });
  }
}