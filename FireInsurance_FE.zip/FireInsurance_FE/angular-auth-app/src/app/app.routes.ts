import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { MyQuotesComponent } from './components/my-quotes/my-quotes.component';
import { NewQuoteComponent } from './components/new-quote/new-quote.component';
import { GetQuoteComponent } from './components/get-quote/get-quote.component';
import { ViewQuoteComponent } from './components/view-quote/view-quote.component';
import { EditQuoteComponent } from './components/edit-quote/edit-quote.component';

import { LandingComponent } from './components/home/home.component'; 

export const routes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'my-quotes', component: MyQuotesComponent },
  { path: 'new-quote', component: NewQuoteComponent },
  { path: 'get-quote', component: GetQuoteComponent },

  { path: 'quotes/new', component: MyQuotesComponent },
  { path: 'quotes/:id', component: ViewQuoteComponent },
  // { path: 'quotes/:id/edit', component: EditQuoteComponent, canActivate: [AuthGuard] },
  { path: 'quotes', component: MyQuotesComponent },
  // { path: '', redirectTo: '/quotes', pathMatch: 'full' }


  { path: 'new-quote/edit', component: NewQuoteComponent },
  { path: 'quotes/:id/edit', component: NewQuoteComponent },

  { path: '**', redirectTo: '' } 
];


 