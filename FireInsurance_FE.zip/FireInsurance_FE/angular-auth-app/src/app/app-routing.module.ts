// import { NgModule } from '@angular/core';
// import { RouterModule, Routes } from '@angular/router';
// import { LandingComponent } from './components/home/home.component';
// import { DashboardComponent } from './components/dashboard/dashboard.component';
// import { MyQuotesComponent } from './components/my-quotes/my-quotes.component';
// import { NewQuoteComponent } from './components/new-quote/new-quote.component';
// import { ViewQuoteComponent } from './components/view-quote/view-quote.component';
// // angular-auth-app\src\app\components\view-quote\view-quote.component.ts
// import { GetQuoteComponent } from './components/get-quote/get-quote.component';

// import { RegisterComponent } from './components/register/register.component';
// import { AuthGuard } from './auth.guard';
// import { LoginComponent } from './components/login/login.component';
 

// const routes: Routes = [
//   { path: '', redirectTo: '/landing', pathMatch: 'full' },
//   { path: 'landing', component: LandingComponent },
//   { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
//   { path: 'my-quotes', component: MyQuotesComponent, canActivate: [AuthGuard] },
//   { path: 'new-quote', component: NewQuoteComponent, canActivate: [AuthGuard] },
//   { path: 'view-quote/:id', component: ViewQuoteComponent, canActivate: [AuthGuard] },
//   { path: 'get-quote', component: GetQuoteComponent, canActivate: [AuthGuard] },
//   { path: 'register', component: RegisterComponent },
//   { path: '', redirectTo: '/register', pathMatch: 'full' },
//   {path: 'login', component: LoginComponent},
//   { path: '', redirectTo: '/login', pathMatch: 'full' },
//   { path: '**', redirectTo: '/landing' }
// ];

// @NgModule({
//   imports: [RouterModule.forRoot(routes)],
//   exports: [RouterModule]
// })
// export class AppRoutingModule { }



import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LandingComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { MyQuotesComponent } from './components/my-quotes/my-quotes.component';
import { NewQuoteComponent } from './components/new-quote/new-quote.component';
import { ViewQuoteComponent } from './components/view-quote/view-quote.component';
import { GetQuoteComponent } from './components/get-quote/get-quote.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';


const routes: Routes = [
  { path: '', redirectTo: '/landing', pathMatch: 'full' },
  { path: 'landing', component: LandingComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'my-quotes', component: MyQuotesComponent, },
  { path: 'new-quote', component: NewQuoteComponent },
  { path: 'view-quote/:id', component: ViewQuoteComponent },
  { path: 'get-quote', component: GetQuoteComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },

  { path: 'new-quote/edit', component: NewQuoteComponent },
  { path: 'quotes/:id/edit', component: NewQuoteComponent },
  
  { path: '**', redirectTo: '/landing' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
