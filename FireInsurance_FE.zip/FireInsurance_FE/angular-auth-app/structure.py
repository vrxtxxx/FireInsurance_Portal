import os

# Base project structure
base_structure = {
    "src/main/java/com/yourcompany/insurance/controller": [],
    "src/main/java/com/yourcompany/insurance/model": [],
    "src/main/java/com/yourcompany/insurance/repository": [],
    "src/main/java/com/yourcompany/insurance/service": [],
    "src/main/java/com/yourcompany/insurance": ["InsuranceApplication.java"],
    "src/main/resources": ["application.properties"]
}

# Create folders and files
for path, files in base_structure.items():
    os.makedirs(path, exist_ok=True)
    for file in files:
        file_path = os.path.join(path, file)
        with open(file_path, "w") as f:
            f.write(f"// {file}\n")  # Optional placeholder

print("✅ Java Spring Boot folder structure created successfully!")
